muesuem assignment

Edwin Dixon 
76241975

steps:
1. open terminal in directory
2. put "make run"
