#if !defined(models)
#define models

#include <iostream>
#include <fstream>
#include <GL/freeglut.h>
using namespace std;

void sun();

void astroExhibit();

void astroTimer(int value);

void rocketheight(unsigned char key, int x, int y);

void flameTimer(int value);

void rocket();

void flames();

void flame();

void rocketDisplay();

void fishDisplay();

void fishs();

void ballTimer(int value);

void lift();

void ballExhibit();

void ball();

void fence();

void fencepost();

#endif
